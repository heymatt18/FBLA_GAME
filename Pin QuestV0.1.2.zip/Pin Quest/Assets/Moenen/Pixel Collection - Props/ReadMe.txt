
			
		��  ��  ��  Moenen Pixel Collection - Props 120+ ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MPC - Character		http://u3d.as/Tjd
	MPC - Environment	http://u3d.as/Tjg
	MPC - Props			http://u3d.as/Tjh
	MPC - Vegetation	http://u3d.as/Tjj
	MPC - Vehicle		http://u3d.as/Tjo
	



Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	These resources can be use in your games, but you can't sell them as game asset.




How to Edit:

	The ase files in "Source File.zip" can be edit with Aseprite.
	



Content List:

    (From Voxel - Free gift convert from my voxel package) 

    Food

        Fruit

			Apple x20
			Banana x15
			Blueberry x8
			Grape x8
			Orange x15
			Peach x5
			Pear x15
			Pineapple x5
			Strawberry x6
			Watermelon x5

		Meat

			Beef x8
			ChickenWing x10
			Pork x8
			PorkChop x10
			Steak x10

		Snack

			Bread x5
			Cake x11
			CakeRoll x4
			Chips x8
			Cola x18
			EggTart x4
			Hamburg x5

		Vegetable

			Cabbage x13
			Carrot x4
			Corn x4
			Cucumber x5
			Eggplant x4
			Mushroom x64
			Pepper x14
			Potato x6
			Scallion x5
			Tomato x6

    Misc

		Anchor x3
		Animal Specimens x24
		Basket x11
		Book x60
		Bottle x42
		Box x46
		Chest x21
		Coin x28
		Crystal x100
		Lamp x28
		Letter x97
		Painting x10

	Weapon

		Axe x11
		Bow x10
		Hammer x8
		Shield x4
		Spear x8
		Staff x8
		Sword x12

