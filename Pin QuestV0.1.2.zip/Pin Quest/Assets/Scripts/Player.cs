﻿namespace MoenenGames.MPCCharacterDemo {
	using System.Collections;
	using System.Collections.Generic;
	using UnityEngine;


    
	public class Player : MonoBehaviour {
        public GameObject menuPanel;
        public float speed;

        void Update()
        {
            Animator ani = GetComponentInChildren<Animator>(true);
            ani.SetBool("isMoving", false);
            
            if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
            {
                transform.localScale = new Vector3(-1f, 1f, 1f);
                ani.SetBool("isMoving", true);
            }
            if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            {
                transform.localScale = new Vector3(1f, 1f, 1f);
                ani.SetBool("isMoving", true);
            }
            if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
            {
                transform.localScale = new Vector3(1f, 1f, 1f);
                ani.SetBool("isMoving", true);
            }
            if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
            {
                transform.localScale = new Vector3(1f, 1f, 1f);
                ani.SetBool("isMoving", true);
            }
            transform.Translate(Input.GetAxisRaw("Horizontal") * speed, Input.GetAxisRaw("Vertical") * speed, 0);


            if(Input.GetKey(KeyCode.M))
            {
                Time.timeScale = 0f;
                menuPanel.SetActive(true);
            }
        }





        /*private void Update () {
            // Animation
            Animator ani = GetComponentInChildren<Animator>(true);
            bool hasSpeed = false;
            bool isHori = false;
            // Movement
            var rig = GetComponent<Rigidbody2D>();
			if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
            {
				rig.velocity = Vector2.left * 5f;
				transform.localScale = new Vector3(-1f, 1f, 1f);
                isHori = true;
            }
            if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            {
				rig.velocity = Vector2.right * 5f;
				transform.localScale = new Vector3(1f, 1f, 1f);
                isHori = true;
            }
            if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
            {
                rig.velocity = Vector2.up * 5f;
                transform.localScale = new Vector3(1f, 1f, 1f);                              
            }
            if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
            {
                rig.velocity = Vector2.down * 5f;
                transform.localScale = new Vector3(1f, 1f, 1f);                            

            }
            if(Input.anyKey == false)
            	rig.velocity = Vector2.zero;
	
			
			for (int i = 0; i < ani.parameterCount; i++) {
				if (ani.parameters[i].name == "Speed") {
					hasSpeed = true;
				}
			}
			if (hasSpeed && isHori)
            {
				ani.SetFloat("Speed", Mathf.Abs(rig.velocity.x));
			}
            if (hasSpeed && !isHori)
            {
                ani.SetFloat("Speed", Mathf.Abs(rig.velocity.y));
            }
			
				}*/
    }
		}

