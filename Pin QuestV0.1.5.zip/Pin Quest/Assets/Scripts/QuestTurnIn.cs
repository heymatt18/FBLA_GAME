﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestTurnIn : MonoBehaviour{
    private bool waitForPress;
    private bool outOfOrder = false;
   
    void Update()
    {
        if (waitForPress && Input.GetKeyDown(KeyCode.E) )
        {
            foreach (Quest quest in GameObject.Find("DataController").GetComponent<DataController>().quests)
            {
                if (quest.objective == gameObject && !quest.isComplete && quest.questStarted)
                {
                    quest.isComplete = true;
                    if (!outOfOrder)
                        quest.getRewards();
                    else
                        quest.isComplete = false;
                    outOfOrder = false;
                }
                else
                {
                    Debug.Log("Set outofOrder to true");
                    outOfOrder = true;
                }
            }
        }
        
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.name == "Player")
        {
            waitForPress = true;
        }
    }

}
