﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestGiver : MonoBehaviour {

    private bool waitForPress;
    void Update()
    {
        if (waitForPress && Input.GetKeyDown(KeyCode.E))
        {
            foreach (Quest quest in GameObject.Find("DataController").GetComponent<DataController>().quests)
            {
                if (quest.questGiver == gameObject && !quest.questStarted && !quest.isComplete)
                {                    
                    quest.questStarted = true;                            

                }
            }
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.name == "Player")
        {
            waitForPress = true;
        }
    }
}
