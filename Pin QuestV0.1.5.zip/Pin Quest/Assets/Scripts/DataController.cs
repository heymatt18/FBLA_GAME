﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class DataController : MonoBehaviour {
    //private string gameDataFileName = "data.json";
    public Quest[] quests;

    private void Start()
    {
        DontDestroyOnLoad(gameObject);
       
    }
    


    /* private void LoadGameData()
     {
         string filePath = Path.Combine(Application.streamingAssetsPath, gameDataFileName);
         if (File.Exists(filePath))
         {
             string dataAsJson = File.ReadAllText(filePath);
             NPCList loadedData = JsonUtility.FromJson<NPCList>(dataAsJson);

             npcList = loadedData;
         }
         else
         {
             Debug.LogError("Cannot Load Game Data!");
         }
     }*/
}
