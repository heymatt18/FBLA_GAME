﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Quest
{
    public string quest;
    public GameObject questGiver;
    public GameObject objective;
   

    public bool questStarted = false;
    public bool isComplete = false;
    public OnQuestComplete[] rewards;

    public bool getIsComplete()
    {
        return isComplete;
    }
    public void getRewards()
    {
        foreach (OnQuestComplete reward in rewards)
            reward.recieveReward();
    }
   
}
