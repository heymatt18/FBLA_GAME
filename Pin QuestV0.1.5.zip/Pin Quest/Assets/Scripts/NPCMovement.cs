﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCMovement : MonoBehaviour
{

    public float moveSpeed;

    private Rigidbody2D myRigidBody; //connects to the sprites rigidbody so it can move 

    public bool isWalking; //determines if the NPC is walking

    public float walkTime; //how long NPC should walk
    private float walkCounter; //keeps track of value ^
    public float waitTime; //how long NPC should stand still
    private float waitCounter; //keeps track of value 
   

    private int walkDirection;

    // Use this for initialization
    void Start()
    {
        myRigidBody = GetComponent<Rigidbody2D>();
        waitCounter = waitTime;
        walkCounter = walkTime;
  
        ChooseDirection();

    }

    // Update is called once per frame
    void Update()
    {
        Animator ani = GetComponentInChildren<Animator>(true);
        ani.SetBool("isMoving", false);
        if (isWalking)
        {
            walkCounter -= Time.deltaTime; //starts counting down walkCounter
            ani.SetBool("isMoving", true);
            switch (walkDirection) //makes an NPC move in a specific direction
            {
                case 0:
                    myRigidBody.velocity = new Vector2(0, moveSpeed); //moving up ( x value equals 0, y value is a positive move speed 
                    break;
                case 1:
                    myRigidBody.velocity = new Vector2(moveSpeed, 0); //move right
                    transform.localScale = new Vector3(1f, 1f, 1f);
                    break;
                case 2:
                    myRigidBody.velocity = new Vector2(0, -moveSpeed); //move down
                    break;
                case 3:
                    myRigidBody.velocity = new Vector2(-moveSpeed, 0); //moveleft
                    transform.localScale = new Vector3(-1f, 1f, 1f);
                    break;
            }

            if (walkCounter < 0)
            {
                isWalking = false;
                waitCounter = waitTime;
            }

        }
        else
        {
            waitCounter -= Time.deltaTime;
            myRigidBody.velocity = Vector2.zero;

            if (waitCounter < 0)
            {
                ChooseDirection();
            }
        }
    }

    public void ChooseDirection() //picks a direction for NPC to move
    {
        walkDirection = Random.Range(0, 4); //picks 0,1,2,3 (N,S,E,W)
        isWalking = true;
        walkCounter = walkTime;
    }
}