﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class OnQuestComplete{

    public string reward;//a stat name or money
    public double amtPerReward;//amt for finishing

    public void recieveReward()
    {
        switch (reward)
        {
            case "teamWork":
                GameObject.Find("Player").GetComponent<Player>().teamWork += (int)amtPerReward;
                break;

            case "intelligence":
                GameObject.Find("Player").GetComponent<Player>().intelligence += (int)amtPerReward;
                break;

            case "creativity":
                GameObject.Find("Player").GetComponent<Player>().creativiity += (int)amtPerReward;
                break;

            case "leaderShip":
                GameObject.Find("Player").GetComponent<Player>().leaderShip+= (int)amtPerReward;
                break;

            case "money":
                GameObject.Find("Player").GetComponent<Player>().money += (int)amtPerReward;
                break;

        }
    }
}
