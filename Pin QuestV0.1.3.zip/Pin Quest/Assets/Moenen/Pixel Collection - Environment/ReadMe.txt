
			
		��  ��  ��  Moenen Pixel Collection - Environment 170+ ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MPC - Character		http://u3d.as/Tjd
	MPC - Environment	http://u3d.as/Tjg
	MPC - Props			http://u3d.as/Tjh
	MPC - Vegetation	http://u3d.as/Tjj
	MPC - Vehicle		http://u3d.as/Tjo
	



Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	These resources can be use in your games, but you can't sell them as game asset.




How to Edit:

	The ase files in "Source File.zip" can be edit with Aseprite.
	



Content List:

    (From Voxel - Free gift convert from my voxel package) 

    Building

		Apartment_0 x12
		Factory x2
		Hospital x6
		House_0 x10
		House_1 x3
		House_2 x3
		House_3 x6
		Office x6
		Oilwell x8
		Stairs x6

	Decoration

		Breakable Object x24
		Chest x21
		Crystal x100
		Flag x96
		Ruin Blood x119
		Ruin x119
		Stone x57
		Street x96

    Furniture

		Animal Specimens x24
		Bed x12
		Cabinet x25
		Clock x12
		Column x14
		Door x12
		Fan x12
		Fireplace x11
		Flower x48
		Lamp x28
		Misc x14
		Painting x10
		Shelf x14
		Sofa x18
		Table Chair x33
		Window x12

