﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Quest : Player
{
    public GameObject Player; 
    protected static List<Quest> questList;
   
    private string objective;
    public Quest(string objective)
    {      
        this.objective = objective;
    }
    public static List<Quest> GetQuests()
    {
        return new List<Quest>(questList);
    }
    public static void removeQuest(Quest finishedQuest)
    {
        questList.Remove(finishedQuest);
    }

    //Gives the description of the quest
    public abstract string getDescription();

    //Gives the objective
    public abstract string getObjective();

    //Gives Rewards
    public abstract void recieveRewards();

}
