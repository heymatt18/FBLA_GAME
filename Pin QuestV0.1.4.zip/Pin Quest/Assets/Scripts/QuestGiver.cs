﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestGiver : MonoBehaviour
{
    private bool waitForPress;
    public bool requiredButtonPress;
    private Quest newQuest;
    public GameObject objective;
    public NPC npcScript;

    void Update()
    { 
        if(waitForPress && Input.GetKeyDown(KeyCode.E))
        {
            if (newQuest == null)
            {
                objective = GameObject.Find("Jeb");
                newQuest = new TalkQuest("Talk to Jeb",objective);
                objective.GetComponent<NPC>().isQuestObjective = true;            
            }
        }
    }


    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.name == "Player")
        {            
            waitForPress = true;
        }
    }
}
