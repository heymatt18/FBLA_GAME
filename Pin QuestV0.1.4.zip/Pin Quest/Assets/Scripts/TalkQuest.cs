﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TalkQuest : Quest
{
    public GameObject person;
    private static int reward = 1;

    public TalkQuest(string objective,GameObject person):base(objective)
    {
        this.person = person;
        questList.Add(this);      
    }

    public void finishQuest()
    {
        person.GetComponent<NPC>().isQuestObjective = false;
        removeQuest(this);
    }

    public override string getDescription()
    {
        return getDescription();
    }
    public override string getObjective()
    {
        return getObjective();
    }

    public override void recieveRewards()
    {
        setTeamWork(getTeamWork()+reward);
    }

}

