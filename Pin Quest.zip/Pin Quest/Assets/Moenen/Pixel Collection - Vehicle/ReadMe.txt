
			
		��  ��  ��  Moenen Pixel Collection - Vehicle 30+ ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MPC - Character		http://u3d.as/Tjd
	MPC - Environment	http://u3d.as/Tjg
	MPC - Props			http://u3d.as/Tjh
	MPC - Vegetation	http://u3d.as/Tjj
	MPC - Vehicle		http://u3d.as/Tjo
	



Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	These resources can be use in your games, but you can't sell them as game asset.




How to Edit:

	The ase files in "Source File.zip" can be edit with Aseprite.
	



Content List:

	(From Voxel - Free gift convert from my voxel package) 

    Air

		Airplane_0 x10
		Airplane_1 x3
		Helicopter_0 x6
		Helicopter_1 x6
    
	Land
    
		Bicycle x16
		Car x27
		F1 x12
		Steamtrain x12
		Truck x10
		VintageCar x13
   
   Sea
    
		Boat x10
		Raft x4
		Submarine x5
		Yacht x2
