
			
		��  ��  ��  Moenen Pixel Collection - Character 100+  ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MPC - Character		http://u3d.as/Tjd
	MPC - Environment	http://u3d.as/Tjg
	MPC - Props			http://u3d.as/Tjh
	MPC - Vegetation	http://u3d.as/Tjj
	MPC - Vehicle		http://u3d.as/Tjo
	

My artworks in GooglePhoto https://goo.gl/photos/cPpgGXN6PaHQsf6K8


Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	These resources can be use in your games, but you can't sell them as game asset.




How to Edit:

	The ase files in "Source File.zip" can be edit with Aseprite.
	
	


Content List: 

Animal

        Bear x6
        Camel x6
        Cat x6
        Caw x6
        Chicken x6
        Crab x4
        Deer x6
        Dog x6
        Dragon x6
        Duck x6
        Fish x8
        Fox x6
        Giraffe x6
        Hedgehog x4
        Horse x6
        Jellyfish x2
        Koala x6
        Leopard x6
        Monkey x6
        Mouse x2
        Panda x6
        Penguin x6
        Pig x6
        Rabbit x6
        Shark x2
        Sheep x6
        Snake x3
        Squid x6
        Squirrel x5
        Tiger x6
        Triceratops x6
        Walrus x6
        Whale x2

    Fighter

        Human

            Axe Man x14
            Axe Soldier x14
            Black Punch Man x14
            Blacksmith Man x14
            Copper Sword Man x14
            Hammer Man x14
            Hammer Soldier x14
            Knife Man x14
            Long Knife Man x14
            Magic Soldier x14
            Pan Dwarf Man x14
            Rod Soldier x14
            Scissors Man x14
            Spear Black Man x14
            Spear Man x14
            Spear Soldier x14
            Spiner Boy x14
            Sword Man 0 x14
            Sword Man 1 x14
            Sword Soldier x13

        Orc

            Big Arm Man x14
            Big Man x14
            Flat Head Lady x14
            Orc Boy x14
            Tall Man x14

        Savage

            Big Mouth Man x14
            Big Nose Man x14
            Crazy Hair Lady x14
            Curly Hair Lady x14
            Dull Man x14
            Flat Head Man x14
            Humpback Man x14
            Moon Head Man x14
            Smile Boy x14
            Tall Lady x14
            Tri Eye Man x14
            Witch Lady x14

    Monster

        Bat x4
        Dook x8
        Hydralisk x6
        Skull x8
        Slime x6
        Spider x6
        Yeti x8
        Zombie x8

    NPC

        Human

            Bag Boy x8
            Black Lady x8
            Black Man x8
            Boss x8
            Buck Teeth Boy x8
            Centaur x8
            Cook x8
            Cow Boy x8
            Crazy Hari Boy x8
            Doctor x8
            Double Head x8
            Earphone Girl x8
            Fat Boy x8
            Fire Hair Girl x8
            Fringe Girl x8
            Gold Hair Girl x8
            Green Lady x8
            Green Sweater Man x8
            Lollipop Girl x8
            Medieval Man x8
            Old Man x8
            Pink Dress Girl x8
            Red Hair Boy x8
            Sandy Boy x8
            Sport Girl x8
            Suit Man 0 x8
            Tramp x8

        Orc

            Big Arm Man x8
            Big Man x8
            Flat Head Lady x8
            Orc Boy x8
            Tall Man x8

        Savage

            Big Mouth Man x8
            Big Nose Man x8
            Crazy Hair Lady x8
            Curly Hair Lady x8
            Dull Man x8
            Flat Head Man x8
            Humpback Man x8
            Moon Head Man x8
            Smile Boy x8
            Tall Lady x8
            Tri Eye Man x8
            Witch Lady x8
